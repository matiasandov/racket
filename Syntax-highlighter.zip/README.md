# Sintax-highlighter

Reflexiona sobre la solución planteada, los algoritmos implementados y sobre el tiempo de ejecución de estos.

En la actual actividad se implementó un resaltador de tokens, en cual se debió hacer uso de la implementación de 
programa funcional aprendida durante el curso, por lo que para lograr la tarea se dividió el programa en funciones
que permitían ir resolviendo "un problema a la vez". Es decir, primero se debió hacer una función para leer el 
archivo json, cuya complejidad es O(n), pues debe de recorrer toda la longitud del archivo. Después se procedió a
implementar una función para separar el nombre del archivo que se recibe como parámetro en la primera de su extensión
para escribir la solución en ese archivo, esta función tiene una complejidad O(n). Posteriormente, ya con el nombre
del archivo, se implementó una función para escribir en dicho archivo los tokens ya clasificados con su respectivo "tag" de html
y "class" (Complejidad O(n)). Después se implementó el clasificador de tokens, el cual con un ciclo, fue iterando sobre
cada expresión regular del archivo y haciendo uso de la función de escribir, escribir su clasificación, su tag y la expresión, 
respectivamente, en el archivo html creado (Complejidad O(n)). Finalmente, se invocó todo el programa dentro de una función main().

El programa tiene una complejidad en tiempo lineal y se completó exitosamente, siendo acompañado de un archivo .css
para poner estilo al archivo de html el cual ayuda a ver de manera visual la distintas clases clasificadas por el programa dándole colores y estilo diferentes.
